<?php
/**
 * index.php is the home page for our website
 *
 * It instantiates our class, htmlPage, and calls the method that streams the initial 
 * html for the top of our page.  The main centre section of this file makes space to 
 * stream the page content.  Finally, it calls the method that streams the final html 
 * of our boilerplate code.
 * 
 * @author David Argles <d.argles@gmx.com>
 * @version 02-01-2014, 21:24h
 * @copyright 2014 Haven Consulting
 */

  /* The following line makes the server display error messages.
     You may uncomment it during development, but don't forget to comment it out again 
     when you're ready to deploy! */
  //ini_set("display_errors", 1);

  /* The next two lines bring in the htmlPage class and create a new instance.
     Don't change these lines! */
  require("library/htmlPage.php");
  $page = new htmlPage();
  /* The next line streams the initial page html.  Don't change this. */
  $page->HTMLstreamTop();
?>
      <!-- The main page content follows.  You can change this as you wish -->
      
      <h3>TrimSite</h3>
      <p>This is the delivery version of TrimSite.  To set it up, see:</p>
	  <ul>
	    <li>
	      the <a href="readme.php">readme file</a>,
	    </li>
	    <li>
	      the <a href="http://argles.org/trimsite/">TrimSite website</a>,
	    </li>
	    <li>
	      the <a href="documentation/">documentation folder</a>,
	    </li>
	    <li>
	      and the internal code documentation in each file.
	    </li>
	  </ul>

      <!-- End of main page content -->
<?php
  /* The final line streams the remaining html.  Don't change this. */
  $page->HTMLstreamBottom();
/**---------------------------------------------
 *             End of File
 *----------------------------------------------
 */
?>

